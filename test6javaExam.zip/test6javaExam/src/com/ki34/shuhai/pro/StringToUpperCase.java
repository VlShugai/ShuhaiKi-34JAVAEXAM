package com.ki34.shuhai.pro;

import java.util.Arrays;

public class StringToUpperCase {

    void stringToUpper(String [][] array){
        Arrays.stream(array).flatMap(Arrays::stream).forEach(e -> System.out.println(e.toUpperCase()));

    }
}
