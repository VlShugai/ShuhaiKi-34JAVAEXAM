package com.ki34.shuhai.pro;

import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Stream;

public class Main {

    public static void main(String[] args) {
        String [][] array = {{"asdsad wqewqe asdsad wqewqe"} ,
                {"asdsad kgjkj asdkjfdskjfsdl"}, {"asdsad kgjkj oreitoriteo"},
                {"asdsad kgjkj oreitoriteo"},{"dskfjkdsfjlk osiajdoiashoimkwq oreitoriteo"}
        };
        StringToUpperCase stringToUpperCase = new StringToUpperCase();
        stringToUpperCase.stringToUpper(array);
    }
}
